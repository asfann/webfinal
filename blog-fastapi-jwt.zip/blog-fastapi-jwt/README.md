# blog-fastapi-jwt

secured mini-blog CRUD app for creating and reading blog posts

authentication using JSON Web Tokens (JWTs)